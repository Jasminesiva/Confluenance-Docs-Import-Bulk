import FilesToCatalogsConverter from "./filesToCatalogsMaker.service";

export default class ConfluenceDocsAdapter {
    public eachFileToSeparatePageConverter = new FilesToCatalogsConverter();
}